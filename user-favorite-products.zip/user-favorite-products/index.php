<?php
// Silent is golden.