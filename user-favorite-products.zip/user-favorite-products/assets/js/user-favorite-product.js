jQuery(document).ready(function($) {
    jQuery(".favorite-button").click(function(e) {
        e.preventDefault(); // Prevent the form from submitting normally

        jQuery.ajax({
            type: "post",
            url: favorite_product_ajax_object.ajaxurl,
            data: {
                action: favorite_product_ajax_object.favorite_action,
                favpoduct_nonce: favorite_product_ajax_object.favorite_nonce,
                get_current_prod_id: favorite_product_ajax_object.get_current_prod_id,
                get_current_login_user_id: favorite_product_ajax_object.get_current_login_user_id,
            },
            beforeSend: function() {
                jQuery(".favorite-button").prop("disabled", true);
            },
            success: function(response) {
                console.log(response);

                if (response.status == 'success') {
                    alert(response.message)
                } else {
                    alert(response.message);
                }
                // Increment the current batch counter
                    // All products have been updated

                     // Refresh the page
                     setTimeout(function() {
                        location.reload();
                    }, 2000);
                // jQuery(".favorite-button").prop("disabled", false);

            },
            error: function(error) {
                console.log(error);
            },
            complete: function() {
                jQuery(".favorite-button").prop("disabled", false);
            }
        });

    });
});