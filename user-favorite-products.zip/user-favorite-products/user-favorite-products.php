<?php
/**
 * @package UserFavoriteProducts
 * Plugin Name: User Favorite Products
 * Description: The User Favorite Products plugin allows users to mark and save their favorite products on your WooCommerce-powered website. It enhances the user experience by providing a convenient way for users to create a personalized list of products they are interested in.
 *  Version: 1.0.0
 * Author:               <a href="https://profiles.wordpress.org/rajanpanchal2028/">Rajan Panchal</a>
 * Author URI:           https://profiles.wordpress.org/rajanpanchal2028/
 * License:              GPLv2 or later
 * License URI:          https://opensource.org/licenses/gpl-license.php
 * Text Domain:          user-favorite-products
 * WC requires at least: 3.0
 * WC tested up to:      7.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	die; // Exit if accessed directly
}

class UserFavoriteProducts{


    public function __construct()
    {

        add_action('admin_notices', array($this, 'dependency_notice'));
        
            add_filter( 'woocommerce_account_menu_items', array( $this, 'user_favorite_product_myaccount_tab' ) );
            
            add_action( 'init', array( $this, 'add_user_favorite_product_endpoint' ) );
            add_action('init', array( $this, 'remove_favorite_product' ));

            add_action( 'woocommerce_account_favorite-products_endpoint', array( $this, 'user_favorite_product_my_account_tab_content' ) );
            add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'add_favorite_button_after_add_to_cart') );

            add_action('wp_enqueue_scripts', array( $this, 'enqueue_favorite_products_scripts') );

            add_action( 'wp_ajax_add_product_into_fav_product', array( $this, 'add_product_into_fav_product' ) );
            add_action( 'wp_ajax_nopriv_add_product_into_fav_product', array( $this, 'add_product_into_fav_product' ) );
    }

    public function dependency_notice()
    {
        if (!class_exists('WooCommerce')) {
            echo '<div class="notice notice-error"><p>';
            echo __('WooCommerce is not installed / Activated. Please install and activate WooCommerce to use User Favorite Products.', 'user-favorite-products');
            echo '</p></div>';            
        }
    }

    public function enqueue_favorite_products_scripts()
    {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '5.15.3');

        wp_enqueue_style('user-favorite-product-style', plugin_dir_url(__FILE__) . 'assets/css/user-favorite-product-style.css', array(), '1.0.0');

        wp_register_script('user-favorite-product', plugin_dir_url(__FILE__) . 'assets/js/user-favorite-product.js', array('jquery'), '1.0', false);

            // Localize the script with data
            $user_favorite_product = array(
                'ajaxurl' 					=>  admin_url( 'admin-ajax.php' ),
			    'favorite_action'			=>  'add_product_into_fav_product',
			    'favorite_nonce'			=>	wp_create_nonce( 'favorite-nonce-security' ),
			    'get_current_prod_id' 		=>  get_the_ID(),
			    'get_current_login_user_id' =>  get_current_user_id(),

            );
            
            wp_localize_script('user-favorite-product', 'favorite_product_ajax_object', $user_favorite_product);
    
            // Enqueue the script
            wp_enqueue_script('user-favorite-product');

    
    }


    public function user_favorite_product_myaccount_tab( $items ) {
        // Add your custom tab to the $items array
        $items['favorite-products'] = 'Favorite Products';
    
        return $items;
    }

    public function add_user_favorite_product_endpoint()
    {
        add_rewrite_endpoint( 'favorite-products', EP_PAGES );
        flush_rewrite_rules();
    }

    public function user_favorite_product_my_account_tab_content() {
        $current_user_id = get_current_user_id();
        $favorite_products = get_user_meta($current_user_id, 'favorite_products', true);
    
        if (!empty($favorite_products)) {
            // Get the favorite products
            $args = array(
                'post_type'      => 'product',
                'post__in'       => $favorite_products,
                'posts_per_page' => -1,
                'orderby'        => 'post__in'
            );
            $favorite_query = new WP_Query($args);
    
            if ($favorite_query->have_posts()) {
                echo '<div class="favorite-products-content">';
                echo '<h3 class="favorite-products-title">Your Favorite Products:</h3>';
                echo '<table class="favorite-products-table">';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Product</th>';
                echo '<th>Remove</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';
    
                while ($favorite_query->have_posts()) {
                    $favorite_query->the_post();
    
                    global $product;
                    $product_id = $product->get_id();
                    $remove_url = wp_nonce_url(
                        add_query_arg('remove_favorite', $product_id),
                        'remove_favorite_' . $product_id,
                        'remove_favorite_nonce'
                    );
                    echo '<tr>';
                    echo '<td><a href="' . get_permalink() . '" class="favorite-product-link">' . get_the_title() . '</a></td>';
                    echo '<td><a href="' . $remove_url . '" class="favorite-product-remove" data-product-id="' . $product_id . '">Remove</a></td>';
                    echo '</tr>';
                }
    
                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            }
            wp_reset_postdata();
        } else {
            // No favorite products found
            echo '<div class="favorite-products-content">';
            echo '<h3 class="favorite-products-title">Your Favorite Products:</h3>';
            echo '<p class="no-favorite-products-msg">You have no favorite products yet.</p>';
            echo '</div>';
        }
    }
    

    public function add_favorite_button_after_add_to_cart() {
        global $product;
        $product_id = $product->get_id();
    
        // Check if the user is logged in
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
    
             // Get the user's favorite products
             $favorite_products = get_user_meta($user_id, 'favorite_products', true);
    
             // Check if the current product is in the user's favorite products
             $is_favorite = in_array($product_id, $favorite_products);

             $button_class = $is_favorite ? 'button favorite-button primary alreadyadded' : 'button favorite-button primary';
    
             $is_favorite_product   = $is_favorite ? 'style="color: red"' : '';
             $change_bg_icon_color  = $is_favorite ? 'fa-heart' : 'fa-heart-o';
            echo '<button type="submit" name="favorite-button" class="' . $button_class . '"><i class="fa '.$change_bg_icon_color.'" '.$is_favorite_product.'></i> Favorite Product</button>';

        }
    }

    public function add_product_into_fav_product(){


        $get_current_prod_id 		= isset($_POST['get_current_prod_id']) ? $_POST['get_current_prod_id'] : '0';
        $get_current_login_user_id 	= isset($_POST['get_current_login_user_id']) ? intval($_POST['get_current_login_user_id']) : 0;
        $nonce_security             = isset($_POST['favpoduct_nonce']) ? $_POST['favpoduct_nonce'] : '';
    
        if ( ! wp_verify_nonce( $nonce_security, 'favorite-nonce-security' ) ) {
            // This nonce is not valid.
            wp_send_json_error( 'Invalid security check' );
    
        } else {
    
             // Check if the product is already in the user's favorite products
             $favorite_products = get_user_meta( $get_current_login_user_id, 'favorite_products', true );
    
             if ( ! is_array( $favorite_products ) ) {
                 $favorite_products = array();
             }
     
             if ( in_array( $get_current_prod_id, $favorite_products ) ) {

                $favorite_products = array_diff($favorite_products, array($get_current_prod_id));
                update_user_meta($get_current_login_user_id, 'favorite_products', $favorite_products);
                 // Product already added to favorites
                 $response = array(
                    'status'  	=> 'success',
                    'code'		=> 404,
                    'message' 	=> 'Product removed from favorites list.',
                );
    
             } else {
                 // Add the product to the user's favorite products
                 
                 $favorite_products[] = $get_current_prod_id;
                 update_user_meta( $get_current_login_user_id, 'favorite_products', $favorite_products );
     
                 // Product added successfully
                 $response = array(
                    'status'  	=> 'success',
                    'code'		=> 200,
                    'message' 	=> 'Product added to favorites list.',
                );
             }
    
             wp_send_json($response);
    
            
        }
        // wp_die();
    }

    public function remove_favorite_product()
    {
        if (isset($_GET['remove_favorite']) && isset($_GET['remove_favorite_nonce'])) {
            $product_id = intval($_GET['remove_favorite']);
            $nonce = $_GET['remove_favorite_nonce'];
    
            if (wp_verify_nonce($nonce, 'remove_favorite_' . $product_id)) {
                $current_user_id = get_current_user_id();
                $favorite_products = get_user_meta($current_user_id, 'favorite_products', true);
    
                // Remove the product ID from the favorite list
                $updated_favorite_products = array_diff($favorite_products, array($product_id));
    
                // Update the user's favorite products
                update_user_meta($current_user_id, 'favorite_products', $updated_favorite_products);
    
                // Redirect back to the favorite products page
                wp_redirect(wc_get_account_endpoint_url('favorite-products'));
                
                exit;
            }
        }
    }
}

if (class_exists( 'UserFavoriteProducts' )) {
    $userfavoriteproducts = new UserFavoriteProducts();
}